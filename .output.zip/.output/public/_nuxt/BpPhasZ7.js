import{j as o}from"./C3tBpsDK.js";const s=o("loading",{state:()=>({isLoading:!0}),actions:{set(t){this.$patch({isLoading:t})}}});export{s as u};
