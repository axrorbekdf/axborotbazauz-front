import{g as n,o,c as s,a as t}from"./C3tBpsDK.js";const i=n({__name:"index",setup(a){return(r,e)=>(o(),s("div",null,e[0]||(e[0]=[t("h1",null,"Xush kelibsiz!",-1)])))}});export{i as default};
